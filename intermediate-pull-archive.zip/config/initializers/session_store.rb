# Be sure to restart your server when you modify this file.

TtmateWeb::Application.config.session_store :cookie_store, key: '_ttmate_web_session'
