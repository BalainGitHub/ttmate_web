# Be sure to restart your server when you modify this file.

# Your secret key is used for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!

# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
# You can use `rake secret` to generate a secure secret key.

# Make sure your secret_key_base is kept private
# if you're sharing your code publicly.
TtmateWeb::Application.config.secret_key_base = 'f60d75abf1bdf37fa8b4d086d77f7e588b0384e4dc71823ac264d81ee2b478ba495d5fc015bd64b7d59f9860d362332f4405637f069562bfdf27738e6e3221c8'
