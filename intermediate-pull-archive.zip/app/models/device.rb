class Device < ActiveRecord::Base
  belongs_to :User
end
