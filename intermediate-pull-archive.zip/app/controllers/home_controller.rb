class HomeController < ApplicationController
	def index
		@title = "travelTmate | Home"
		@head = "travelTmate"
	end
end
